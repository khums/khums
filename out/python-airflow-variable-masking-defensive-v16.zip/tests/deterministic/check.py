"""Canonical RewardKit adapter for the deterministic pytest prepass."""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
OUT = Path(os.environ.get("VERIFIER_DIR", os.environ.get("RESULT_DIR", "/logs/verifier")))
CONFIG = json.loads((HERE / "verifier.json").read_text(encoding="utf-8"))

NAMES = [f"test_explicit_public_group[{group}]" for group in CONFIG["public_groups"]]
NAMES += [f"test_implicit_upstream_behavior[{case['id']}]" for case in CONFIG["implicit"]]
NAMES += ["test_required_artifacts"]
# Weights belong to protected effects, not rows. Rows that observe the same
# effect (overlapping public and private checks) share that effect's weight
# once: an effect scores 1 only if every row observing it passes, and the
# deterministic score is the weighted mean over effects, so no overlapping
# check is counted twice. Each row also carries its effect's full weight, so
# collapsing rows per effect (max or any single row) gives the same totals.
EFFECTS = {
    # Core security: independent ways a secret can escape. Each one can fail on
    # its own (verified with partial fixes): a leaf-only fix fails only
    # redact_subtree_masking, a container-only fix fails only
    # redact_depth_masking, and an over-broad merge walk fails only
    # merge_depth_bound.
    "redact_depth_masking": ("core_security", 35),     # sensitive keys nested past max_depth are masked
    "redact_subtree_masking": ("core_security", 15),   # a container under a deep sensitive key is masked throughout
    "merge_depth_bound": ("core_security", 25),        # merge() does not re-insert original secrets past max_depth
    # Secondary: legitimate behavior, compatibility, build and artifacts.
    "upstream_compatibility": ("secondary", 7),        # G2, G3 and the upstream suite (core tests deselected)
    "legitimate_masking": ("secondary", 4),
    "legitimate_preservation": ("secondary", 5),
    "legitimate_merge_restore": ("secondary", 4),
    "compilation": ("secondary", 2),
    "artifact_contract": ("secondary", 3),
}
ROW_EFFECTS = {
    "test_explicit_public_group[G1]": "redact_depth_masking",
    "test_explicit_public_group[G2]": "upstream_compatibility",
    "test_explicit_public_group[G3]": "upstream_compatibility",
    "test_explicit_public_group[G4]": "compilation",
    "test_explicit_public_group[G5]": "merge_depth_bound",
    "test_implicit_upstream_behavior[depth_regressions]": "redact_depth_masking",
    "test_implicit_upstream_behavior[deep_key_variants]": "redact_depth_masking",
    "test_implicit_upstream_behavior[deep_secret_via_list]": "redact_depth_masking",
    "test_implicit_upstream_behavior[deep_nested_secret_value]": "redact_subtree_masking",
    "test_implicit_upstream_behavior[merge_past_depth_bound]": "merge_depth_bound",
    "test_implicit_upstream_behavior[masker_regressions]": "legitimate_masking",
    "test_implicit_upstream_behavior[deep_public_preserved]": "legitimate_preservation",
    "test_implicit_upstream_behavior[merge_within_bound_restores]": "legitimate_merge_restore",
    "test_implicit_upstream_behavior[upstream_secrets_masker_suite]": "upstream_compatibility",
    "test_required_artifacts": "artifact_contract",
}
ROWS = {name: (EFFECTS[effect][0], effect, EFFECTS[effect][1]) for name, effect in ROW_EFFECTS.items()}
assert set(ROWS) == set(NAMES), sorted(set(ROWS) ^ set(NAMES))
assert set(ROW_EFFECTS.values()) == set(EFFECTS)
for _case in CONFIG["implicit"]:
    assert ROW_EFFECTS[f"test_implicit_upstream_behavior[{_case['id']}]"] == _case["effect"], _case["id"]
WEIGHTS = {name: ROWS[name][2] for name in NAMES}
CLASS = {name: ROWS[name][0] for name in NAMES}
EFFECT = {name: ROWS[name][1] for name in NAMES}
_EFFECT_TOTAL = sum(weight for _, weight in EFFECTS.values())
_CORE_TOTAL = sum(weight for cls, weight in EFFECTS.values() if cls == "core_security")
assert _CORE_TOTAL >= 0.6 * _EFFECT_TOTAL, (_CORE_TOTAL, _EFFECT_TOTAL)
# Still >= 60% if a reviewer folds the two redact effects into one.
_FOLDED = _CORE_TOTAL - EFFECTS["redact_subtree_masking"][1]
assert _FOLDED >= 0.6 * (_EFFECT_TOTAL - EFFECTS["redact_subtree_masking"][1]), _FOLDED


def _effect_scores(rows: list[dict]) -> dict:
    scores = {}
    for effect, (cls, weight) in EFFECTS.items():
        members = [r for r in rows if EFFECT.get(r["name"]) == effect]
        score = float(bool(members) and all(r["score"] == 1.0 for r in members))
        scores[effect] = {"class": cls, "weight": weight, "score": score,
                          "rows": [r["name"] for r in members]}
    return scores


def _summary(rows: list[dict], reason: str) -> dict:
    effects = _effect_scores(rows)
    earned = sum(e["weight"] * e["score"] for e in effects.values())
    passed = sum(row["status"] == "passed" for row in rows)
    return {
        "strict_pass": bool(rows) and passed == len(rows),
        "strict_score": float(bool(rows) and passed == len(rows)),
        "deterministic_score": round(earned / _EFFECT_TOTAL, 6) if _EFFECT_TOTAL else 0.0,
        "passed_checks": passed,
        "failed_checks": sum(row["status"] == "failed" for row in rows),
        "error_checks": sum(row["status"] == "error" for row in rows),
        "skipped_checks": sum(row["status"] == "skipped" for row in rows),
        "total_checks": len(rows),
        "tests": rows,
        "by_name": {row["name"]: row for row in rows},
        "by_effect": effects,
        "test_weights": WEIGHTS,
        "weight_classes": {cls: {"earned": sum(e["weight"] * e["score"] for e in effects.values() if e["class"] == cls),
                                 "possible": sum(e["weight"] for e in effects.values() if e["class"] == cls)}
                           for cls in ("core_security", "secondary")},
        "effect_groups": EFFECT,
        "reason": reason,
    }


def run_prepass() -> dict:
    OUT.mkdir(parents=True, exist_ok=True)
    junit = OUT / "deterministic-junit.xml"
    cmd = [sys.executable, "-m", "pytest", str(HERE / "pytest_checks.py"),
           "--junit-xml", str(junit), "-q", "-p", "no:cacheprovider", "--tb=short"]
    try:
        junit.unlink(missing_ok=True)
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=1100)
        (OUT / "deterministic-pytest.log").write_text(proc.stdout + proc.stderr, encoding="utf-8")
        root = ET.parse(junit).getroot()
        found = {}
        for case in root.iter("testcase"):
            name = case.get("name", "")
            failure, error, skipped = (case.find(tag) for tag in ('failure', 'error', 'skipped'))
            issue = failure if failure is not None else error if error is not None else skipped
            message = '' if issue is None else (issue.get('message') or '')[:1600]
            status = 'passed' if issue is None else 'skipped' if skipped is not None else 'error' if error is not None else 'failed'
            if 'SUBMISSION_ERROR:' in message or 'SourceScopeError' in message:
                category = 'submission_scope_or_replay_error'
                status = 'failed'
            elif 'VALIDATION_ERROR:' in message:
                category = 'validation_execution_error'
                status = 'error'
            elif status == 'error':
                category = 'setup_or_execution_error'
            elif status == 'skipped':
                category = 'not_executed'
            elif name == 'test_required_artifacts':
                category = 'artifact_contract' if issue is not None else 'passed'
            else:
                category = 'behavioral_failure' if issue is not None else 'passed'
            found[name] = {
                'name': name, 'status': status,
                'score': 1.0 if status == 'passed' else 0.0,
                'weight': WEIGHTS.get(name, 0), 'message': message,
                'failure_category': category,
            }
        rows = [found.get(name, {"name": name, "status": "error", "score": 0.0,
                                "weight": weight, "message": "pytest row missing"})
                for name, weight in WEIGHTS.items()]
        result = _summary(rows, "pytest completed" if proc.returncode == 0 else "pytest failures")
    except Exception as exc:
        rows = [{"name": name, "status": "error", "score": 0.0, "weight": weight,
                 "message": f"prepass infrastructure error: {exc}"} for name, weight in WEIGHTS.items()]
        result = _summary(rows, "deterministic prepass infrastructure error")
    (OUT / "deterministic_reward.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    lines = [f"deterministic score={result['deterministic_score']:.6f}",
             f"{result['passed_checks']} passed; {result['failed_checks']} failed; {result['error_checks']} errors; {result['skipped_checks']} skipped"]
    lines.extend(f"{row['name']}: {row['status']} {row.get('message', '')}" for row in rows)
    (OUT / "test_output.log").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return result


# The observation prepass needs pytest, not RewardKit discovery. In particular,
# retain its evidence even when the scoring dependency is unavailable.
if __name__ == "__main__" and "--prepass" in sys.argv:
    summary = run_prepass()
    raise SystemExit(0 if summary["strict_pass"] else 1)

import rewardkit as rk
from rewardkit import criterion


@criterion(description="Precomputed protected effect {effect_name}: every observing row passed.")
def deterministic_effect(workspace: Path, effect_name: str) -> float:
    try:
        data = json.loads((OUT / "deterministic_reward.json").read_text(encoding="utf-8"))
        return float(data["by_effect"][effect_name]["score"])
    except Exception:
        return 0.0


# One criterion per protected effect so overlapping rows are never double-weighted.
for _effect, (_cls, _weight) in EFFECTS.items():
    rk.deterministic_effect(_effect, weight=_weight, name=_effect)



