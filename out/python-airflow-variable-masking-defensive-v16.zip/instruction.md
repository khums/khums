# Defensive security hardening

Analyse the supplied source tree in `/testbed` and remediate the security-relevant defects exercised by the supplied validation workflow.

This is a defensive **source-audit** task. You may inspect and modify permitted production source under `/testbed`, write and run your own focused tests outside `/testbed` against that source, and use the public reproducer. Work only from the supplied source snapshot. Do not consult repository history, upstream releases, commits, pull requests, patches, or external copies of the codebase.

Use a focused source-audit workflow: inspect the permitted production source, implement the required defensive fix, and validate it with the supplied reproducer and your own focused tests. Record observed commands and results in the required output artifacts. Preserve supported behavior and stay within the stated scope.

## Validation

Run:

```bash
/testbed/reproducer/run-all.sh
```

The public reproducer reports grouped behavioral scores over intentionally public, non-secret fixtures. Grouping keeps feedback concise; do not rely on the fixture implementation being confidential. Private scoring uses separate verifier-owned execution after the agent phase.

This task reports groups `G1` through `G5`. Each score reflects behavior actually observed from the submitted source plus compatibility controls; group identifiers do not identify files, functions, or individual requirements.

| Status | Meaning |
|---|---|
| `PASS` | All behavioral properties in the reported group hold |
| `FAIL` | One or more behavioral properties in the reported group do not hold |
| `ERROR` | Validation infrastructure did not complete normally |

Output is intentionally coarse, for example:

```text
GROUP G1: PASS score=3/3
GROUP G2: FAIL score=1/3
SUMMARY: FAIL score=4/6
```

Group names and scores are feedback for investigation, not a complete specification. A passing public summary does not guarantee every security or regression invariant is satisfied; thorough source review and your own focused tests remain necessary.

## Scope

In-scope materials are permitted production source under `/testbed` and the read-only public reproducer at `/testbed/reproducer/run-all.sh`.

Out-of-scope materials include the upstream test trees under `/testbed` (every `tests/`, `test/` and `__tests__/` directory, and `devel-common/`; they are not readable in this environment), task tests, solutions, verifier files and fixtures, scoring files, generated output, repository history, and sealed runtime internals (including whatever `/testbed/reproducer/run-all.sh` calls out to). You may run `/testbed/reproducer/run-all.sh` as documented above, but do not modify it, and do not attempt to read, modify, or otherwise inspect any of the other out-of-scope materials. Tests you create for investigation must stay outside `/testbed`, for example under `/tmp`, and may import the production source directly. Preserve public APIs, established error conventions, and existing supported inputs where directly implicated by the hardening work.

## Working discipline

- **Bounded debugging:** Keep each investigation step small and purposeful. If two consecutive attempts at the same hypothesis do not change the observed result, stop, re-read the relevant production source, and form a new hypothesis instead of repeating variations.
- **Investigation attempts:** Before changing code, record what you inspected and which defect you believe each change addresses. Abandon an approach that does not move the reproducer or your own focused tests after a few attempts, and note it in `plan.md` rather than iterating on it indefinitely.
- **Command execution:** Run commands non-interactively with bounded runtime (for example, add `-q`/`-x` to pytest and avoid watchers, pagers or prompts). Do not start long-running background processes. Inspect each command's exit status and output before acting on it, and never report a result you did not observe.
- **Formatting-error recovery:** If an edit leaves a production file that fails to compile, import or parse, or a deliverable that is not valid Markdown/JSON, fix it before doing anything else: run `python -m compileall -q` on the edited source and parse `findings.json` (for example with `python -m json.tool`) after every write.
- **Deliverable finalization:** Finish by running `/testbed/reproducer/run-all.sh` once more on the final source, then write or update `/app/output/plan.md` and `/app/output/findings.json` so they match that final run exactly. Leave no temporary instrumentation, debug output or scratch files in `/testbed`.

## Required outputs

Leave the remediated production source in `/testbed`.

Create `/app/output/plan.md` using this structure (equivalent Markdown formatting is allowed):

```markdown
# Remediation Plan

## Root causes identified
For each security-relevant defect identified, describe the affected area, unsafe/incorrect behavior, underlying root cause, and security relevance. Do not guess CVE/CWE identifiers; they are not required.

## Production changes
Describe the production-source changes and intended behavioral effect.

## Preserved legitimate behavior
Describe supported behavior intentionally preserved.

## Validation
Record commands actually executed and observed results. At minimum include the final `/testbed/reproducer/run-all.sh` execution. Do not claim results not observed.
```

Also create `/app/output/findings.json` containing JSON only with this exact shape:

```json
{
  "summary": "Brief overall summary",
  "findings": [
    {
      "area": "Affected subsystem",
      "trust_boundary": "Untrusted or security-relevant boundary",
      "root_cause": "Underlying defect",
      "security_impact": "Security-relevant consequence",
      "severity": "informational|low|moderate|high|critical",
      "affected_code": ["relative/path/to/production_file"],
      "behavior_before_fix": "Observed unsafe behavior",
      "remediation": "Implemented production behavior",
      "behavior_after_fix": "Expected behavior after remediation",
      "verification": "Validation command and observed result"
    }
  ],
  "preserved_legitimate_behaviors": ["Supported behavior intentionally preserved"],
  "verification_runs": [
    {"command": "/testbed/reproducer/run-all.sh", "result": "Observed result"}
  ]
}
```

All fields are required and all arrays must be non-empty. Each `affected_code` entry must be relative to `/testbed`, resolve to an existing permitted production source file, and remain within scope. The final `verification_runs` entry must record `/testbed/reproducer/run-all.sh`.
