#!/usr/bin/env python3
"""Run sealed Java behavior cases as an unprivileged user; expose groups and bounded property diagnostics."""
from __future__ import annotations

import json
import os
import pwd
import re
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

TESTBED = Path("/testbed")
MODULE_REL = Path("plc4j/drivers/opcua")
SOURCE_REL = MODULE_REL / "src/test/java/org/apache/plc4x/java/opcua/context/SecurityBehaviorProbeTest.java"
KEYSTORE_REL = MODULE_REL / "src/test/java/org/apache/plc4x/java/opcua/KeystoreGenerator.java"
SERVER_REL = MODULE_REL / "src/test/java/org/eclipse/milo/examples/server/ProbeMiloServer.java"
SEALED = Path("/opt/task-checker/probe")
PUBLIC_REPORT = SEALED.parent / "internal/probe-public.json"
GROUPS = {
    "G1": ("p01", "p05", "p08", "p13", "p17", "p18"),
    "G2": ("p02", "p03", "p07", "p10", "p19", "p20"),
    "G3": ("p04", "p06", "p11", "p12", "p21", "p22"),
    "G4": ("p09", "p14", "p15", "p16", "p23", "p24"),
}
HIDDEN = tuple(f"h{index:02d}" for index in range(1, 13))
# Public behavior properties. Each public case belongs to exactly one; the
# descriptions state the required property only, never fixture details.
PROPERTIES = {
    "supported_connections": (
        ("p01", "p03", "p06", "p08", "p10", "p12", "p14", "p15", "p16", "p18"),
        "legitimate signed, encrypted and deliberately unprotected connections (including explicit opt-outs) keep working"),
    "modified_message_rejection": (
        ("p02", "p13", "p17"),
        "a message altered after the peer protected it is rejected"),
    "peer_identity": (
        ("p04", "p05", "p19"),
        "a server whose identity has not been verified is not trusted"),
    "protection_negotiation": (
        ("p07", "p11", "p20", "p21", "p22"),
        "the client never settles on weaker protection than the caller requested"),
    "default_and_credential_policy": (
        ("p09", "p23", "p24"),
        "default connection settings and credential handling fail safe"),
}
assert sorted(c for cases, _ in PROPERTIES.values() for c in cases) == sorted(
    c for cases in GROUPS.values() for c in cases)
# Submitted Java runs only as this unprivileged account, never as root.
RUNNER_USER = "plc4x-runner"
RUN_ROOT = Path("/var/lib/plc4x-probe")
MAX_REPORT_BYTES = 8 * 1024 * 1024


def emit_error(diagnostic: str = "") -> None:
    for group, cases in GROUPS.items():
        print(f"GROUP {group}: ERROR score=0/{len(cases)}")
    print(f"SUMMARY: ERROR score=0/{sum(map(len, GROUPS.values()))}")
    if diagnostic:
        print(f"DIAGNOSTIC: {diagnostic}")


def _reports(module: Path):
    """Yield parsed surefire reports, refusing anything the runner could aim elsewhere."""
    reports = module / "target/surefire-reports"
    if reports.is_symlink() or not reports.is_dir():
        return
    for report in sorted(reports.glob("TEST-*SecurityBehaviorProbeTest.xml")):
        try:
            fd = os.open(report, os.O_RDONLY | os.O_NOFOLLOW)
        except OSError:
            continue
        with os.fdopen(fd, "rb") as handle:
            info = os.fstat(handle.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_REPORT_BYTES:
                continue
            yield ET.fromstring(handle.read())


def _kind(problem: ET.Element, is_error: bool) -> str:
    if not is_error:
        return "assertion"
    name = (problem.get("type") or "").rsplit(".", 1)[-1]
    return "unexpected " + (re.sub(r"[^A-Za-z0-9_$]", "", name)[:60] or "exception")


def parse_cases(module: Path) -> dict[str, str]:
    rows: dict[str, str] = {}
    for root in _reports(module):
        for case in root.iter("testcase"):
            name = case.get("name", "")
            if not name or name in rows:
                continue
            if case.find("skipped") is not None:
                rows[name] = "skipped"
            elif case.find("failure") is not None or case.find("error") is not None:
                rows[name] = "failed"
            else:
                rows[name] = "passed"
    return rows


def parse_failures(module: Path) -> dict[str, str]:
    failures: dict[str, str] = {}
    for root in _reports(module):
        for case in root.iter("testcase"):
            problem = case.find("failure")
            is_error = problem is None
            if problem is None:
                problem = case.find("error")
            if problem is not None:
                failures[case.get("name", "")] = _kind(problem, is_error) + ": " + " ".join(
                    (problem.get("message") or problem.text or "").split())[:800]
    return failures


def _chown_tree(root: Path, uid: int, gid: int) -> None:
    os.lchown(root, uid, gid)
    for directory, dirs, files in os.walk(root):
        for name in dirs + files:
            os.lchown(os.path.join(directory, name), uid, gid)


def _runner_env(home: Path, local_repo: Path) -> dict[str, str]:
    # Built from scratch: nothing from the caller's (root or verifier)
    # environment, such as API keys or credentials, reaches submitted code.
    return {
        "PATH": "/opt/java/openjdk/bin:/usr/local/bin:/usr/bin:/bin",
        "JAVA_HOME": "/opt/java/openjdk",
        "HOME": str(home),
        "LANG": "C.UTF-8",
        "MAVEN_OPTS": f"-Xmx4g -Dmaven.repo.local={local_repo} -Dmaven.repo.local.tail=/opt/maven-cache",
    }


def run(mode: str) -> tuple[dict[str, str], int, str, dict[str, str]]:
    runner = pwd.getpwnam(RUNNER_USER)
    RUN_ROOT.mkdir(mode=0o711, parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="probe-", dir=RUN_ROOT) as temporary:
        # Only root and the runner can enter the workspace; the agent cannot.
        workdir = Path(temporary)
        workbed = workdir / "source"
        home = workdir / "home"
        local_repo = workdir / "m2"
        shutil.copytree(TESTBED, workbed, symlinks=True,
                        ignore=shutil.ignore_patterns("target", ".git"))
        module = workbed / MODULE_REL
        source = workbed / SOURCE_REL
        keystore_helper = workbed / KEYSTORE_REL
        server_helper = workbed / SERVER_REL
        if source.exists() or server_helper.exists():
            raise RuntimeError("probe source collision")
        source.parent.mkdir(parents=True, exist_ok=True)
        keystore_helper.parent.mkdir(parents=True, exist_ok=True)
        server_helper.parent.mkdir(parents=True, exist_ok=True)
        source.write_bytes((SEALED / source.name).read_bytes())
        server_helper.write_bytes((SEALED / server_helper.name).read_bytes())
        if not keystore_helper.exists():
            keystore_helper.write_bytes((SEALED / keystore_helper.name).read_bytes())
        home.mkdir()
        local_repo.mkdir()
        _chown_tree(workdir, runner.pw_uid, runner.pw_gid)
        os.chmod(workdir, 0o700)
        selection = "p*" if mode == "public" else "h*"
        command = ["setpriv", f"--reuid={runner.pw_uid}", f"--regid={runner.pw_gid}",
                   "--clear-groups", "--no-new-privs", "--",
                   "mvn", "-o", "-B", "-ntp", "-Pwith-java", "-Dplc4x-code-generation.version=1.9.0",
                   "-pl", "plc4j/drivers/opcua", "-am",
                   f"-Dtest=SecurityBehaviorProbeTest#{selection}",
                   "-Dsurefire.failIfNoSpecifiedTests=false", "test"]
        child = subprocess.Popen(command, cwd=workbed, text=True, stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                                 env=_runner_env(home, local_repo), start_new_session=True)
        try:
            log, _ = child.communicate(timeout=420)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            child.communicate()
            raise
        finally:
            # Nothing the runner started may outlive the run.
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        rows = parse_cases(module)
        return rows, child.returncode, (log or "")[-16000:], parse_failures(module)


def build_diagnostic(log: str) -> str:
    if "COMPILATION ERROR" in log or "Compilation failure" in log:
        where = "the validation harness" if "/src/test/java/" in log else "the submitted production source"
        return (f"compilation of {where} failed; production code must compile and public API "
                "signatures used by existing callers must stay unchanged")
    return "the validation run did not complete normally (crash or timeout); this is not a behavioral result"


def print_properties(rows: dict[str, str], failures: dict[str, str]) -> None:
    for name, (cases, description) in PROPERTIES.items():
        passed = sum(rows.get(case) == "passed" for case in cases)
        status = "PASS" if passed == len(cases) else "FAIL"
        print(f"PROPERTY {name}: {status} {passed}/{len(cases)} - {description}")
        if status == "FAIL":
            kinds: dict[str, int] = {}
            for case in cases:
                if rows.get(case) != "passed":
                    kind = failures.get(case, "not run").split(":", 1)[0]
                    kinds[kind] = kinds.get(kind, 0) + 1
            print("  observed: " + ", ".join(f"{count} {kind}" for kind, count in sorted(kinds.items())))


def main() -> int:
    if len(sys.argv) != 2 or sys.argv[1] not in {"public", "hidden"}:
        raise SystemExit(2)
    mode = sys.argv[1]
    expected = {name for group in GROUPS.values() for name in group} if mode == "public" else set(HIDDEN)
    if mode == "public":
        PUBLIC_REPORT.unlink(missing_ok=True)
    try:
        rows, returncode, log, failures = run(mode)
    except (OSError, subprocess.TimeoutExpired, ET.ParseError, RuntimeError) as exc:
        rows, returncode, log, failures = {}, 2, str(exc), {}
    complete = expected <= rows.keys()
    if mode == "public":
        # The public command exposes only group scores. Root-owned verifier data
        # stays beneath /opt/task-checker, which is inaccessible to the agent.
        PUBLIC_REPORT.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        os.chmod(PUBLIC_REPORT.parent, 0o700)
        PUBLIC_REPORT.write_text(json.dumps({"complete": complete, "returncode": returncode,
                                             "cases": rows, "failures": failures}, indent=2) + "\n",
                                 encoding="utf-8")
        os.chmod(PUBLIC_REPORT, 0o600)
    if mode == "hidden":
        output = Path(os.environ.get("VERIFIER_DIR", "/logs/verifier")) / "internal/probe-hidden.json"
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps({"complete": complete, "returncode": returncode,
                                      "cases": rows, "failures": failures,
                                      "log_tail": log}, indent=2) + "\n", encoding="utf-8")
        return 0 if complete and returncode == 0 and all(rows[n] == "passed" for n in expected) else 1
    if not complete:
        emit_error(build_diagnostic(log))
        return 2
    total = sum(rows[name] == "passed" for name in expected)
    if total == len(expected) and returncode != 0:
        emit_error(build_diagnostic(log))
        return 2
    for group, names in GROUPS.items():
        passed = sum(rows[name] == "passed" for name in names)
        status = "PASS" if passed == len(names) else "FAIL"
        print(f"GROUP {group}: {status} score={passed}/{len(names)}")
    status = "PASS" if total == len(expected) else "FAIL"
    print(f"SUMMARY: {status} score={total}/{len(expected)}")
    print_properties(rows, failures)
    return 0 if total == len(expected) else 1


if __name__ == "__main__":
    raise SystemExit(main())
