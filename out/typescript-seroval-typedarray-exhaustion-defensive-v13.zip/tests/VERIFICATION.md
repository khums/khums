# Verification

## Deterministic gate (binary reward)
`test.sh` first freezes `packages/seroval/src`, `/app/output` and the public-run
evidence log into a root-owned snapshot, then runs the pytest prepass
(`deterministic/check.py --prepass` → `pytest_checks.py`) in a suite RewardKit
never discovers. RewardKit scores only the precomputed rows in a separate
minimal suite (`check.py`, `verifier.json`, `process/check.py`).

16 weighted rows (total weight 75):

| Rows | Weight | Purpose |
|---|---|---|
| `test_explicit_public_group[G1..G3]` | 5 | Sealed public probe groups; overlapping security + compatibility checks |
| `test_explicit_public_group[G4]` | 4 | Sealed public probe group; overlapping security + compatibility checks |
| `test_implicit_upstream_behavior[*]` (4) | 4 | Upstream suites and package build in a chrooted replay |
| `test_private_behavior[*]` security (5) | 6 | Holdout view-bounds and non-buffer backing-source cases |
| `test_private_behavior[supported_*]` (2) | 4 | Supported typed-array / DataView round trips |
| `test_required_artifacts` | 2 | `plan.md`/`findings.json` contract + evidence that the reported reproducer status/score was actually observed on the submitted source digest |

Each row carries `failure_category` (`behavioral_failure`, `build_failure`,
`artifact_contract`, `validation_execution_error`, `submission_scope_or_replay_error`,
`setup_or_execution_error`). Probe/replay timeouts and crashes are `error`, not
behavioral failures.

`binary_reward = 1` iff every row passes and `process/check.py` confirms the
plan headings.

## Semantic judge (continuous reward only)
Runs only after a successful deterministic pass, with `ANTHROPIC_API_KEY` and a
real agent trajectory. Dimensions: `process`, `output_quality`, `validity`,
`task_quality` over `judge_inputs/` (instruction, trajectory + scope reading aid,
frozen artifacts, staged production source, deterministic rows, public probe
output, verifier-only `case_semantics.md`).

`continuous_reward = 0.55·deterministic + 0.20·min(plan gate, process judge) + 0.25·output_quality`
(output_quality omitted from the denominator when the judge did not run).

## Oracle evidence
Public probe: 16 executions over 8 distinct commands in four overlapping groups.
Measured on the baseline checkout: no-op fails all 4 public security checks and
all 5 private security rows (compatibility checks pass). FIX-1 passes all 12
new cases and the full upstream suite (808 tests) and builds. Partial fixes are
caught: backing-source check only fails 5 cases (all length overruns); bounds
check only fails 4 (all non-buffer sources); bounds ignoring element size fails
uint16_claim_overruns_buffer. No absolute size cap is tested.

## Fallback
If staging, freezing or RewardKit fails, observed prepass rows are preserved,
`verifier_error.json` is written, and the binary reward is 0.

## v13 public probe layout

Four mixed groups run four commands each. Eight unique checks (four
security-boundary, one boundary-acceptance and three upstream compatibility
suites) are distributed twice across the groups; the agent receives only
aggregate group scores. v13 removed the unstated 1,000,000 element/byte cap
(serializer and decoder) from public, private and reference material.
