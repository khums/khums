#!/bin/sh
set -eu
cd "${SRC_ROOT:-/testbed}"
patch -s -p1 < /solution/patches/01-opcua-secure-channel-backport.patch
OUT="${OUTPUT_DIR:-/app/output}"
mkdir -p "$OUT"
cp /solution/plan.md /solution/findings.json "$OUT"/
