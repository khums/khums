# Oracle solution plan

Use baseline `5a4d5bdb4c1b0e9356eff00af198bdb6aa960f26` and preserve valid OPC UA secure connections. Apply the directly compatible first fix, then backport the three later security behaviors onto this baseline's APIs. The later commits depend on intervening source changes and cannot be cherry-picked verbatim.

1. Make secure-channel signature checks fail closed: valid signed messages continue, while tampered, unsigned, or unverifiable protected messages terminate processing.
2. Require server certificate validation against the configured trust material. Invalid or untrusted certificates must prevent channel establishment; an explicitly documented insecure option must remain intentional.
3. During endpoint discovery, require both security mode and security policy to match, then choose the strongest compatible endpoint rather than the first or weakest match.
4. Apply protected defaults and refuse credentials over cleartext. Do not continue from unauthenticated discovery into a weaker secure channel.

Validate with the Maven build and focused OPC UA tests. Behavioral checks cover valid traffic, tampered signatures, unknown certificates, exact endpoint-policy matching, strongest-compatible selection, protected defaults, cleartext credential rejection, and discovery downgrade rejection. Preserve supported signed, encrypted, and explicitly unprotected connections. The Oracle patch changes production Java only; the verifier supplies the test fixtures.
