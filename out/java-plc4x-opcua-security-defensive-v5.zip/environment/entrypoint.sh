#!/usr/bin/env bash
set -euo pipefail
fail(){ echo "entrypoint: $*" >&2; exit 1; }
[ -d /testbed ] || fail "missing workspace"
[ ! -e /testbed/.git ] || fail "history present"
[ -d /testbed/reproducer ] || fail "missing reproducer"
[ "$(stat -c '%U' /testbed/reproducer)" = root ] || fail "reproducer ownership drift"
[ "$(stat -c '%a' /testbed/reproducer)" = 555 ] || fail "reproducer permissions drift"
id agent >/dev/null 2>&1 || fail "agent user missing"
[ -d /app/output ] || fail "output directory missing"
chown agent:agent /app/output
exec gosu agent "$@"
