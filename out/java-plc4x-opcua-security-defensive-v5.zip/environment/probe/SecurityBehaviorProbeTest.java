/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.plc4x.java.opcua.context;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import javax.crypto.Cipher;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.plc4x.java.DefaultPlcDriverManager;
import org.apache.plc4x.java.api.PlcConnection;
import org.apache.plc4x.java.opcua.KeystoreGenerator;
import org.apache.plc4x.java.opcua.TestCertificateGenerator;
import org.apache.plc4x.java.opcua.config.OpcuaConfiguration;
import org.apache.plc4x.java.opcua.protocol.chunk.PayloadConverter;
import org.apache.plc4x.java.opcua.readwrite.BinaryPayload;
import org.apache.plc4x.java.opcua.readwrite.ApplicationDescription;
import org.apache.plc4x.java.opcua.readwrite.ChunkType;
import org.apache.plc4x.java.opcua.readwrite.EndpointDescription;
import org.apache.plc4x.java.opcua.readwrite.GetEndpointsRequest;
import org.apache.plc4x.java.opcua.readwrite.GetEndpointsResponse;
import org.apache.plc4x.java.opcua.readwrite.MessagePDU;
import org.apache.plc4x.java.opcua.readwrite.MessageSecurityMode;
import org.apache.plc4x.java.opcua.readwrite.OpcuaOpenRequest;
import org.apache.plc4x.java.opcua.readwrite.OpcuaProtocolLimits;
import org.apache.plc4x.java.opcua.readwrite.OpenChannelMessageRequest;
import org.apache.plc4x.java.opcua.readwrite.PascalByteString;
import org.apache.plc4x.java.opcua.readwrite.PascalString;
import org.apache.plc4x.java.opcua.readwrite.SequenceHeader;
import org.apache.plc4x.java.opcua.readwrite.UserTokenPolicy;
import org.apache.plc4x.java.opcua.readwrite.UserTokenType;
import org.apache.plc4x.java.opcua.security.MessageSecurity;
import org.apache.plc4x.java.opcua.security.SecurityPolicy;
import org.eclipse.milo.examples.server.ProbeMiloServer;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

/** Sealed behavior checks. Assertions concern accepted or rejected traffic and connections. */
public class SecurityBehaviorProbeTest {
    private static ProbeMiloServer server;
    private static Path serverCertificate;
    private static Path otherCertificate;
    private static X509Certificate serverX509;
    private static X509Certificate otherX509;
    private static Path clientKeyStore;
    private static Path trustStore;

    @BeforeAll
    static void startServer() throws Exception {
        Path temp = Files.createTempDirectory("opcua-probe-");
        System.setProperty("java.io.tmpdir", temp.toString());
        Path security = temp.resolve("server/security");
        Path trusted = security.resolve("pki/trusted/certs");
        Files.createDirectories(trusted);
        String uri = "urn:org.apache:plc4x";
        KeystoreGenerator serverIdentity = new KeystoreGenerator("password", 2048, uri);
        KeystoreGenerator clientIdentity = new KeystoreGenerator("changeit", 2048, uri, "plc4x_plus_milo", "client");
        KeystoreGenerator otherIdentity = new KeystoreGenerator("changeit", 2048, uri, "other", "other-server");
        serverX509 = serverIdentity.getCertificate();
        otherX509 = otherIdentity.getCertificate();
        try (FileOutputStream out = new FileOutputStream(security.resolve("example-server.pfx").toFile())) {
            serverIdentity.writeKeyStoreTo(out);
        }
        clientKeyStore = temp.resolve("client.p12");
        try (FileOutputStream out = new FileOutputStream(clientKeyStore.toFile())) {
            clientIdentity.writeKeyStoreTo(out);
        }
        try (FileOutputStream out = new FileOutputStream(trusted.resolve("client.crt").toFile())) {
            clientIdentity.writeCertificateTo(out);
        }
        serverCertificate = temp.resolve("server.crt");
        otherCertificate = temp.resolve("other.crt");
        try (FileOutputStream out = new FileOutputStream(serverCertificate.toFile())) {
            serverIdentity.writeCertificateTo(out);
        }
        try (FileOutputStream out = new FileOutputStream(otherCertificate.toFile())) {
            otherIdentity.writeCertificateTo(out);
        }
        java.security.KeyStore trust = java.security.KeyStore.getInstance("PKCS12");
        trust.load(null, "changeit".toCharArray());
        trust.setCertificateEntry("server", serverIdentity.getCertificate());
        trustStore = temp.resolve("trusted.p12");
        try (FileOutputStream out = new FileOutputStream(trustStore.toFile())) {
            trust.store(out, "changeit".toCharArray());
        }
        server = new ProbeMiloServer();
        server.startup().get(30, TimeUnit.SECONDS);
    }

    @AfterAll
    static void stopServer() throws Exception {
        if (server != null) server.shutdown().get(30, TimeUnit.SECONDS);
    }

    private static String address(String options) {
        return "opcua:tcp://localhost:12686?endpoint-port=12686&request-timeout=5000&negotiation-timeout=5000"
            + (options.isEmpty() ? "" : "&" + options);
    }

    private static String key() {
        return "key-store-file=" + clientKeyStore + "&key-store-password=changeit&key-store-type=pkcs12";
    }

    private static String secure(String extra) {
        return address("discovery=false&" + key() + "&server-certificate-file=" + serverCertificate
            + "&security-policy=Basic256Sha256&message-security=SIGN_ENCRYPT" + (extra.isEmpty() ? "" : "&" + extra));
    }

    private static void connects(String url) throws Exception {
        try (PlcConnection connection = new DefaultPlcDriverManager().getConnection(url)) {
            assertTrue(connection.isConnected());
        }
    }

    private static void rejects(String url) {
        assertThrows(Exception.class, () -> {
            try (PlcConnection ignored = new DefaultPlcDriverManager().getConnection(url)) {
                if (ignored.isConnected()) throw new AssertionError("unexpected connection");
            }
        });
    }

    private static Conversation channel(X509Certificate local, X509Certificate remote, SecurityPolicy policy, MessageSecurity mode) {
        Conversation c = Mockito.mock(Conversation.class);
        when(c.getLimits()).thenReturn(new OpcuaProtocolLimits(8196L, 8196L, 81960L, 10L));
        when(c.getLocalCertificate()).thenReturn(local);
        when(c.getRemoteCertificate()).thenReturn(remote);
        when(c.getSecurityPolicy()).thenReturn(policy);
        when(c.getMessageSecurity()).thenReturn(mode);
        when(c.isSymmetricEncryptionEnabled()).thenReturn(mode == MessageSecurity.SIGN_ENCRYPT);
        when(c.isSymmetricSigningEnabled()).thenReturn(mode != MessageSecurity.NONE);
        when(c.getLocalNonce()).thenReturn(new byte[32]);
        when(c.getRemoteNonce()).thenReturn(new byte[32]);
        return c;
    }

    private static void messageRoundTrip(SecurityPolicy policy, MessageSecurity mode, boolean alter, int size) throws Exception {
        Entry<PrivateKey, X509Certificate> from = TestCertificateGenerator.generate(2048, "CN=sender", 3600);
        Entry<PrivateKey, X509Certificate> to = TestCertificateGenerator.generate(2048, "CN=receiver", 3600);
        byte[] body = new byte[size];
        for (int i = 0; i < size; i++) body[i] = (byte) (i * 37 + 11);
        OpcuaOpenRequest request = new OpcuaOpenRequest(ChunkType.FINAL,
            new OpenChannelMessageRequest(0, new PascalString(policy.getSecurityPolicyUri()),
                new PascalByteString(from.getValue().getEncoded().length, from.getValue().getEncoded()),
                new PascalByteString(20, DigestUtils.sha1(to.getValue().getEncoded()))),
            new BinaryPayload(new SequenceHeader(1, 1), body));
        EncryptionHandler sender = new EncryptionHandler(channel(from.getValue(), to.getValue(), policy, mode), from.getKey());
        List<MessagePDU> encoded = sender.encodeMessage(request, () -> 1);
        assertTrue(encoded.size() == 1);
        MessagePDU incoming = encoded.get(0);
        EncryptionHandler receiver = new EncryptionHandler(channel(to.getValue(), from.getValue(), policy, mode), to.getKey());
        if (alter) {
            byte[] bytes = PayloadConverter.toStream(incoming);
            int bodyStart = 12 + 12 + policy.getSecurityPolicyUri().length()
                + from.getValue().getEncoded().length + 20;
            int rsaBlock = 256;
            assertTrue((bytes.length - bodyStart) % rsaBlock == 0);
            Cipher cipher = policy.getAsymmetricEncryptionAlgorithm().getCipher();
            for (int offset = bodyStart; offset < bytes.length; offset += rsaBlock) {
                cipher.init(Cipher.DECRYPT_MODE, to.getKey());
                byte[] plain = cipher.doFinal(bytes, offset, rsaBlock);
                if (offset + rsaBlock == bytes.length) plain[plain.length - 8] ^= 0x20;
                cipher.init(Cipher.ENCRYPT_MODE, to.getValue().getPublicKey());
                byte[] encrypted = cipher.doFinal(plain);
                System.arraycopy(encrypted, 0, bytes, offset, rsaBlock);
            }
            assertThrows(Exception.class, () -> receiver.decodeMessage(PayloadConverter.pduFromStream(bytes, false)));
        } else {
            OpcuaOpenRequest decoded = (OpcuaOpenRequest) receiver.decodeMessage(incoming);
            assertArrayEquals(body, ((BinaryPayload) decoded.getMessage()).getPayload());
        }
    }

    private static void untrustedPeerRejected(X509Certificate presented) throws Exception {
        OpcuaDriverContext context = new OpcuaDriverContext();
        context.openKeyStore(Mockito.mock(OpcuaConfiguration.class));
        assertThrows(Exception.class, () -> context.getCertificateVerifier().checkCertificateTrusted(presented));
    }

    private static EndpointDescription endpoint(SecurityPolicy policy, MessageSecurityMode mode, int level) {
        UserTokenPolicy anonymous = new UserTokenPolicy(new PascalString("anonymous"),
            UserTokenType.userTokenTypeAnonymous, new PascalString(""), new PascalString(""), new PascalString(""));
        return new EndpointDescription(new PascalString("opc.tcp://localhost:12686"),
            Mockito.mock(ApplicationDescription.class), new PascalByteString(0, new byte[0]), mode,
            new PascalString(policy.getSecurityPolicyUri()), List.of(anonymous), new PascalString(""), (short) level);
    }

    private static EndpointDescription discovered(List<EndpointDescription> offered,
        SecurityPolicy requestedPolicy, MessageSecurity requestedMode) {
        Conversation exchange = Mockito.mock(Conversation.class);
        OpcuaDriverContext context = Mockito.mock(OpcuaDriverContext.class);
        OpcuaConfiguration config = Mockito.mock(OpcuaConfiguration.class);
        GetEndpointsResponse response = Mockito.mock(GetEndpointsResponse.class);
        when(exchange.getSecurityPolicy()).thenReturn(SecurityPolicy.NONE);
        when(context.getEndpoint()).thenReturn("opc.tcp://localhost:12686");
        when(context.getHost()).thenReturn("localhost");
        when(context.getPort()).thenReturn("12686");
        when(context.getTransportEndpoint()).thenReturn("");
        when(config.getSecurityPolicy()).thenReturn(requestedPolicy);
        when(config.getMessageSecurity()).thenReturn(requestedMode);
        when(response.getEndpoints()).thenReturn(offered);
        when(exchange.submit(Mockito.any(GetEndpointsRequest.class), Mockito.eq(GetEndpointsResponse.class)))
            .thenReturn(CompletableFuture.completedFuture(response));
        return new SecureChannel(exchange, context, config, null).onDiscoverGetEndpointsRequest().join();
    }

    @Test void p01() throws Exception { messageRoundTrip(SecurityPolicy.Basic256Sha256, MessageSecurity.SIGN, false, 96); }
    @Test void p02() throws Exception { messageRoundTrip(SecurityPolicy.Basic256Sha256, MessageSecurity.SIGN, true, 96); }
    @Test void p03() throws Exception { connects(secure("")); }
    @Test void p04() throws Exception { untrustedPeerRejected(serverX509); }
    @Test void p05() { rejects(address("discovery=false&" + key() + "&server-certificate-file=" + otherCertificate + "&security-policy=Basic256Sha256")); }
    @Test void p06() throws Exception { connects(address("discovery=false&" + key() + "&server-certificate-file=" + serverCertificate + "&trust-store-file=" + trustStore + "&trust-store-password=changeit&security-policy=Basic256Sha256")); }
    @Test void p07() { rejects(address("discovery=true&" + key() + "&security-policy=Basic256Sha256&message-security=SIGN_ENCRYPT")); }
    @Test void p08() throws Exception { connects(address("discovery=false&security-policy=NONE")); }
    @Test void p09() { rejects(address("discovery=false&security-policy=NONE&username=user&password=password1")); }
    @Test void p10() throws Exception { connects(address("discovery=false&security-policy=NONE&username=user&password=password1&allow-insecure-credentials=true")); }
    @Test void p11() { assertThrows(Exception.class, () -> discovered(List.of(
        endpoint(SecurityPolicy.Basic256Sha256, MessageSecurityMode.messageSecurityModeNone, 10),
        endpoint(SecurityPolicy.NONE, MessageSecurityMode.messageSecurityModeSignAndEncrypt, 20)),
        SecurityPolicy.Basic256Sha256, MessageSecurity.SIGN_ENCRYPT)); }
    @Test void p12() throws Exception { messageRoundTrip(SecurityPolicy.Basic256Sha256, MessageSecurity.SIGN_ENCRYPT, false, 160); }
    @Test void p13() throws Exception { messageRoundTrip(SecurityPolicy.Basic256Sha256, MessageSecurity.SIGN_ENCRYPT, true, 160); }
    @Test void p14() throws Exception { connects(address("discovery=false&" + key() + "&server-certificate-file=" + serverCertificate + "&security-policy=Basic256Sha256&insecure-certificate-verification=true")); }
    @Test void p15() throws Exception { connects(address("discovery=false&" + key() + "&security-policy=Basic256Sha256&message-security=SIGN&server-certificate-file=" + serverCertificate)); }
    @Test void p16() throws Exception { connects(secure("username=user&password=password1")); }
    @Test void p17() throws Exception { messageRoundTrip(SecurityPolicy.Basic256, MessageSecurity.SIGN_ENCRYPT, true, 81); }
    @Test void p18() throws Exception { messageRoundTrip(SecurityPolicy.Basic256, MessageSecurity.SIGN_ENCRYPT, false, 81); }
    @Test void p19() throws Exception { untrustedPeerRejected(otherX509); }
    @Test void p20() { assertThrows(Exception.class, () -> discovered(List.of(
        endpoint(SecurityPolicy.Basic256Sha256, MessageSecurityMode.messageSecurityModeSignAndEncrypt, 40)),
        SecurityPolicy.Basic256Sha256, MessageSecurity.SIGN)); }
    @Test void p21() { assertThrows(Exception.class, () -> discovered(List.of(
        endpoint(SecurityPolicy.Basic256, MessageSecurityMode.messageSecurityModeSignAndEncrypt, 40)),
        SecurityPolicy.Basic256Sha256, MessageSecurity.SIGN_ENCRYPT)); }
    @Test void p22() { assertEquals(80, discovered(List.of(
        endpoint(SecurityPolicy.Basic256Sha256, MessageSecurityMode.messageSecurityModeSignAndEncrypt, 80),
        endpoint(SecurityPolicy.Basic256Sha256, MessageSecurityMode.messageSecurityModeSignAndEncrypt, 20)),
        SecurityPolicy.Basic256Sha256, MessageSecurity.SIGN_ENCRYPT).getSecurityLevel()); }
    @Test void p23() { rejects(address("discovery=false&security-policy=NONE&username=admin&password=password2")); }
    @Test void p24() { rejects(address("discovery=false")); }

    @Test void h01() throws Exception { messageRoundTrip(SecurityPolicy.Basic256, MessageSecurity.SIGN, false, 143); }
    @Test void h02() throws Exception { messageRoundTrip(SecurityPolicy.Basic256, MessageSecurity.SIGN, true, 143); }
    @Test void h03() throws Exception { messageRoundTrip(SecurityPolicy.Basic256Sha256, MessageSecurity.SIGN_ENCRYPT, true, 63); }
    @Test void h04() throws Exception { untrustedPeerRejected(otherX509); }
    @Test void h05() { assertThrows(Exception.class, () -> discovered(List.of(
        endpoint(SecurityPolicy.NONE, MessageSecurityMode.messageSecurityModeSignAndEncrypt, 30)),
        SecurityPolicy.Basic256Sha256, MessageSecurity.SIGN_ENCRYPT)); }
    @Test void h06() { assertEquals(90, discovered(List.of(
        endpoint(SecurityPolicy.Basic256Sha256, MessageSecurityMode.messageSecurityModeSignAndEncrypt, 10),
        endpoint(SecurityPolicy.Basic256Sha256, MessageSecurityMode.messageSecurityModeSignAndEncrypt, 90)),
        SecurityPolicy.Basic256Sha256, MessageSecurity.SIGN_ENCRYPT).getSecurityLevel()); }
    @Test void h07() throws Exception { connects(address("discovery=false&security-policy=NONE&allow-insecure-credentials=true")); }
    @Test void h08() throws Exception { connects(secure("username=admin&password=password2")); }
    @Test void h09() throws Exception { messageRoundTrip(SecurityPolicy.Basic256, MessageSecurity.SIGN_ENCRYPT, true, 231); }
    @Test void h10() { assertThrows(Exception.class, () -> discovered(List.of(
        endpoint(SecurityPolicy.Basic256Sha256, MessageSecurityMode.messageSecurityModeSign, 75)),
        SecurityPolicy.Basic256Sha256, MessageSecurity.SIGN_ENCRYPT)); }
    @Test void h11() { rejects(address("discovery=false&security-policy=NONE&username=user&password=password2")); }
    @Test void h12() { rejects(address("discovery=false&username=user&password=password1")); }
}
