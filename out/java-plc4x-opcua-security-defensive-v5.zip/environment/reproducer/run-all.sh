#!/usr/bin/env bash
set -u

if ! command -v sudo >/dev/null 2>&1; then
  for group in G1 G2 G3 G4; do echo "GROUP ${group}: ERROR score=0/6"; done
  echo "SUMMARY: ERROR score=0/24"
  exit 2
fi
status=0
output=$(sudo -n /usr/local/bin/run-sealed-probe public 2>/dev/null) || status=$?
if [ -z "$output" ]; then
  for group in G1 G2 G3 G4; do echo "GROUP ${group}: ERROR score=0/6"; done
  echo "SUMMARY: ERROR score=0/24"
  exit 2
fi
printf '%s\n' "$output"
exit "$status"
