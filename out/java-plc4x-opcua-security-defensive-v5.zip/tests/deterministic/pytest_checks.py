"""Deterministic, behavior-based checks for the supplied PLC4X source tree."""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

# RewardKit upload discovery imports every Python module under tests/ before
# Dockerfile dependencies are installed. Define pytest cases only in the runtime.
try:
    import pytest
except ModuleNotFoundError as exc:
    if exc.name != "pytest":
        raise
    pytest = None

TESTBED = Path(os.environ.get("TESTBED", "/testbed"))
OUTPUT = Path(os.environ.get("OUTPUT_DIR", "/app/output"))
VERIFIER = Path(os.environ.get("VERIFIER_DIR", "/logs/verifier"))
BASELINE = Path("/opt/checker-baseline")
REPRODUCER = TESTBED / "reproducer/run-all.sh"
SEALED = Path("/opt/task-checker/probe/run-sealed-probe.py")
PUBLIC_REPORT = Path("/opt/task-checker/internal/probe-public.json")
MANIFEST = Path(__file__).parent / "support/protected_tests.sha256"
GROUPS = ("G1", "G2", "G3", "G4")
PUBLIC_CASES = tuple(f"p{index:02d}" for index in range(1, 25))
HIDDEN_CASES = tuple(f"h{index:02d}" for index in range(1, 13))
FINDING_KEYS = {
    "area", "trust_boundary", "root_cause", "security_impact", "severity",
    "affected_code", "behavior_before_fix", "remediation", "behavior_after_fix", "verification",
}


def _run(command: list[str], timeout: int = 900) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, cwd=TESTBED, text=True, stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT, timeout=timeout, check=False)


if pytest is not None:
    @pytest.fixture(scope="session")
    def public_probe() -> dict:
        result = _run([str(REPRODUCER)])
        pattern = re.compile(r"^GROUP (G[1-4]): (PASS|FAIL|ERROR) score=(\d+)/(\d+)$", re.M)
        rows: dict[str, tuple[str, int, int]] = {}
        for match in pattern.finditer(result.stdout):
            group, status, passed, total = match.groups()
            assert group not in rows, f"duplicate group {group}"
            rows[group] = (status, int(passed), int(total))
        assert set(rows) == set(GROUPS), f"public reproducer incomplete: {result.stdout[-500:]}"
        assert all(total == 6 for _, _, total in rows.values()), "public group size changed"
        assert PUBLIC_REPORT.is_file(), "sealed public probe produced no verifier report"
        data = json.loads(PUBLIC_REPORT.read_text(encoding="utf-8"))
        assert data.get("complete") and set(data.get("cases", {})) == set(PUBLIC_CASES), "sealed public probe incomplete"
        assert sum(passed for _, passed, _ in rows.values()) == sum(
            status == "passed" for status in data["cases"].values()), "public report disagrees with grouped output"
        data["reproducer_returncode"] = result.returncode
        return data


    @pytest.fixture(scope="session")
    def hidden_probe() -> dict:
        result = _run([str(SEALED), "hidden"])
        report = VERIFIER / "internal/probe-hidden.json"
        assert report.is_file(), f"sealed probe produced no report: {result.stdout[-500:]}"
        data = json.loads(report.read_text(encoding="utf-8"))
        assert data.get("complete"), f"sealed probe incomplete: {data.get('log_tail', '')[-1200:]}"
        return data


    @pytest.mark.parametrize("case_id", PUBLIC_CASES)
    def test_sec_public_case(public_probe: dict, case_id: str) -> None:
        assert public_probe["cases"].get(case_id) == "passed", f"public behavior {case_id} failed"


    @pytest.mark.parametrize("case_id", HIDDEN_CASES)
    def test_sec_hidden_case(hidden_probe: dict, case_id: str) -> None:
        assert hidden_probe["cases"].get(case_id) == "passed", f"sealed behavior {case_id} failed"


    def _tree(root: Path) -> dict[str, str]:
        records = {}
        for directory, dirs, files in os.walk(root, followlinks=False):
            dirs[:] = [name for name in dirs if name not in {".git", "target", "build", "out", ".idea", "__pycache__", "reproducer"}]
            for name in files:
                path = Path(directory) / name
                if path.is_symlink():
                    records[path.relative_to(root).as_posix()] = "symlink:" + os.readlink(path)
                else:
                    records[path.relative_to(root).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
        return records


    @pytest.fixture(scope="session")
    def changed_paths() -> set[str]:
        baseline = _tree(BASELINE)
        current = _tree(TESTBED)
        return {name for name in baseline.keys() | current.keys() if baseline.get(name) != current.get(name)}


    def _production(path: str) -> bool:
        return path.endswith(".java") and "/src/main/java/" in path


    @pytest.mark.usefixtures("changed_paths")
    def test_func_scope_compliance(changed_paths: set[str]) -> None:
        assert changed_paths, "no source changes submitted"
        bad = sorted(path for path in changed_paths if not _production(path))
        assert not bad, f"out-of-scope file changes: {bad[:12]}"


    def test_func_protected_tests_unmodified() -> None:
        assert MANIFEST.is_file(), "protected-test manifest missing"
        for line in MANIFEST.read_text(encoding="utf-8").splitlines():
            digest, rel = line.split("  ", 1)
            path = TESTBED / rel
            assert path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == digest, f"protected test changed: {rel}"


    @pytest.mark.usefixtures("changed_paths")
    def test_func_deliverables(changed_paths: set[str]) -> None:
        plan = OUTPUT / "plan.md"
        findings = OUTPUT / "findings.json"
        assert plan.is_file() and not plan.is_symlink() and len(plan.read_text(encoding="utf-8").split()) >= 50
        assert findings.is_file() and not findings.is_symlink()
        data = json.loads(findings.read_text(encoding="utf-8"))
        assert set(data) == {"summary", "findings", "preserved_legitimate_behaviors", "verification_runs"}
        assert isinstance(data["summary"], str) and data["summary"].strip()
        assert isinstance(data["findings"], list) and data["findings"]
        changed_prod = {path for path in changed_paths if _production(path)}
        listed: set[str] = set()
        for finding in data["findings"]:
            assert isinstance(finding, dict) and set(finding) == FINDING_KEYS
            assert finding["severity"] in {"informational", "low", "moderate", "high", "critical"}
            assert all(isinstance(finding[key], str) and finding[key].strip()
                       for key in FINDING_KEYS - {"severity", "affected_code"})
            assert isinstance(finding["affected_code"], list) and finding["affected_code"]
            for rel in finding["affected_code"]:
                assert isinstance(rel, str) and _production(rel) and (TESTBED / rel).is_file()
                listed.add(rel)
        assert changed_prod <= listed, f"changed production files absent from findings: {sorted(changed_prod - listed)}"
        assert isinstance(data["preserved_legitimate_behaviors"], list) and data["preserved_legitimate_behaviors"]
        assert isinstance(data["verification_runs"], list) and data["verification_runs"]
        assert data["verification_runs"][-1].get("command") == "/testbed/reproducer/run-all.sh"


    @pytest.mark.usefixtures("public_probe", "hidden_probe")
    def test_func_build(public_probe, hidden_probe) -> None:
        assert public_probe.get("complete"), "public probe did not complete compilation"
        assert hidden_probe.get("complete"), "sealed probe did not complete compilation"
        if all(status == "passed" for status in public_probe["cases"].values()):
            assert public_probe.get("returncode") == 0 and public_probe.get("reproducer_returncode") == 0, "public Maven build did not complete successfully"
        if all(status == "passed" for status in hidden_probe["cases"].values()):
            assert hidden_probe.get("returncode") == 0, "sealed Maven build did not complete successfully"
