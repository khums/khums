Verifier-only interpretation guide for the PLC4X OPC UA client source audit.
The seeded behaviors concern acceptance of modified signed messages, reliance on
an unverified server identity, selection of a connection mode weaker than the
caller requested, and unsafe default/credential policy. The public probe mixes
these with supported signed and encrypted connections, explicit local
diagnostic opt-outs, and legitimate unprotected anonymous connections. Public
output shows G1-G4 group scores plus one PROPERTY line per behavior class with
a pass count, a one-line statement of the required property, and failure kinds
(assertion or unexpected exception class); it never shows fixture data. Treat
deterministic results and behavior_summary.json as authoritative for observed
behavior. A failure in valid_supported_behavior contradicts a claim that all
supported behavior was preserved. Judge the explanation against the candidate's
own changes and evidence; do not require specific code symbols, wording, or the
reference patch structure. Deterministic weights: each security case weighs 2
(46 of 63, 73%), each supported-behavior control 1, each structural check 1.
