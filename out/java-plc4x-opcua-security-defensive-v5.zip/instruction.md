# Defensive source hardening

Analyse the supplied Java source tree in `/testbed` and remediate security-relevant defects found through source review and the supplied validation workflow.

This is a defensive source-audit task. You have the complete source snapshot and may run the project and focused tests. Investigate failures through code review and controlled experiments, implement general fixes, and preserve supported behavior.

Work only from the supplied source snapshot. Do not consult repository history, upstream releases, commits, pull requests, patches, advisories, or external copies of the codebase.

1. Work in concrete, bounded steps. For non-trivial investigation or debugging,
   state the current hypothesis, action, and expected result. Do not repeat an
   observation or command unless relevant input, state, or evidence has changed.

2. Keep debugging hypothesis-driven. Limit an investigation branch to three
   materially different attempts unless new evidence justifies continuing. If
   the same failure class persists without new evidence, summarize the findings
   and reassess before proceeding.

3. Keep terminal operations bounded, recoverable, and concise. Use appropriate
   timeouts for commands that might hang. Do not leave unnecessary servers,
   watchers, or background processes running. Prefer targeted excerpts and
   summarized logs over large output dumps.

4. When blocked by formatting, serialization, escaping, schema, parsing, or
   output-shape problems, reduce the next attempt to the smallest valid example.
   Do not retry an unchanged malformed input.

5. Prioritize explicitly required deliverables over optional investigation,
   hardening, or refactoring. Leave sufficient time to validate required
   outputs. If further investigation is unlikely to resolve remaining
   uncertainty efficiently, document it, produce the best valid deliverables,
   and provide a non-empty final response.

## Validation

Run:

```bash
/testbed/reproducer/run-all.sh
```

The workflow evaluates the current source on every invocation. It reports four mixed groups and a summary, each with a coarse score, followed by one `PROPERTY` line per required behavior class: its pass count, a one-line statement of the property, and, when it fails, the kind of failure observed (an unmet assertion or an unexpected exception class). If the run cannot complete, a `DIAGNOSTIC` line says whether compilation failed and where.

| Status | Meaning |
| --- | --- |
| `PASS` | The tested property holds |
| `FAIL` | Source violates a required property |
| `ERROR` | Validation infrastructure did not complete normally |

Diagnostics are bounded: they name the failing property, never the test fixtures. Continue source review and focused project testing as needed.

Do not modify, inspect beyond normal execution, instrument, replace, or bypass the reproducer to obtain additional diagnostics.

## Scope

In-scope materials are production Java files matching:

```text
/testbed/**/src/main/java/**/*.java
```

and normal execution of the read-only public reproducer:

```text
/testbed/reproducer/run-all.sh
```

Production Java in any module may be changed when relevant to the remediation.

Out-of-scope materials include every `src/test/**` tree, the reproducer implementation, task tests, solutions, verifier files and fixtures, scoring files, generated output including every `build/` and `target/` directory, repository history, and sealed runtime internals. Do not modify or attempt to inspect out-of-scope materials.

Tests or temporary programs created for investigation must remain outside the submitted production source tree.

Preserve public APIs, established error conventions, and supported inputs unless a change is directly necessary to remove a security defect.

Avoid broad disabling of functionality when a narrower remediation can preserve intended behavior safely. Existing explicit opt-outs must remain deliberate and limited to the behavior they control.

## Required outputs

Leave the remediated production source in `/testbed`.

Create a substantive `/app/output/plan.md` describing:

- the root causes identified;
- the production changes made;
- the legitimate behaviors intentionally preserved; and
- the validation commands run and their observed results.

Also create `/app/output/findings.json` containing JSON only, with this exact shape:

```json
{
  "summary": "Brief overall summary",
  "findings": [
    {
      "area": "Affected subsystem",
      "trust_boundary": "Untrusted input boundary",
      "root_cause": "Underlying defect",
      "security_impact": "Security-relevant consequence",
      "severity": "informational|low|moderate|high|critical",
      "affected_code": ["module/src/main/java/.../ProductionFile.java"],
      "behavior_before_fix": "Observed unsafe behavior",
      "remediation": "Implemented production behavior",
      "behavior_after_fix": "Expected behavior after remediation",
      "verification": "Validation command and observed result"
    }
  ],
  "preserved_legitimate_behaviors": ["Supported behavior intentionally preserved"],
  "verification_runs": [
    {"command": "/testbed/reproducer/run-all.sh", "result": "Observed result"}
  ]
}
```

All fields are required and all arrays must be non-empty.

Each `affected_code` entry must be relative to `/testbed`, resolve to an existing production Java file under a `src/main/java` tree, and remain within the permitted scope. Findings may list related production files involved in the defect even when they were not modified, but together the findings must account for every production file changed.

The final `verification_runs` entry must record `/testbed/reproducer/run-all.sh` with its observed result.
